package recoding;

public class Num_15649_N_M_re {

	public static void main(String[] args) {
		

	}

}
