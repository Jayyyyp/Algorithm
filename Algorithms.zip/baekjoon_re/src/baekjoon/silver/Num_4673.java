package baekjoon.silver;

public class Num_4673 {

	public static void main(String[] args) {
		
		// 브론즈 2231문제 참고

	}

}
