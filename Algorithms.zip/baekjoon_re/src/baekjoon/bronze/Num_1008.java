package baekjoon.bronze;

import java.util.Scanner;

public class Num_1008 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		double num1 = scan.nextDouble();
		double num2 = scan.nextDouble();
		System.out.println(num1/num2);
		
		scan.close();
	}
	
}
