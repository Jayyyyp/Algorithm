package baekjoon.bronze;

public class Num_prac {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
